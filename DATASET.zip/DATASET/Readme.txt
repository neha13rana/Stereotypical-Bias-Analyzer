This folder 'DATASET' contains all the datasets that we have used for making the new combined dataset.

We have utilized all these datasets for synthesizing in order to make dataset more balanced and to have data for all possible biases.
